const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', (req, res) => {
  const query = 'SELECT applicant_name, loan_amount FROM master_loan_csv LIMIT 10';
  db.query(query, (err, results) => {
    if (err) {
      console.error('MySQL Error:', err.message);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});

module.exports = router;
